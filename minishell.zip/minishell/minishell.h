#ifndef MINISHELL_H
# define MINISHELL_H
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct s_all
{
    int signal_exit;
}   t_all;

char	*ft_strjoin(char const *s1, char const *s2);
char	*ft_substr(char const *s, unsigned int start, size_t len);
char	*ft_strchr(const char *s, int c);
size_t	ft_strlen(const char *s);
char	*get_next_line(int fd);

#endif