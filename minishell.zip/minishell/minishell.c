#include "minishell.h"

t_all   global;

void    ft_print_init()
{
    char    *command;

    while (global.signal_exit == 0)
    {
        write(1, "Minion's Minishell $> ", 20);
        command = get_next_line(0);
        printf("COMANDO INTRODUCIDO -> %s\n", command);
    }
}

int main()
{
    ft_print_init();
    return (0);
}