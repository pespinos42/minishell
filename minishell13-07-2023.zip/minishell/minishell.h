#ifndef MINISHELL_H
# define MINISHELL_H
# include <stdio.h>
# include <stdlib.h>
# include <readline/readline.h>
# include <readline/history.h>

typedef struct s_all
{
	int		*map;
	int		map_elements;
	int		close_position;
	int		character_error;
	int		counter_c1;
	int		counter_c2;
	char		*str_order; // = readLine("...")
}   t_all;

#endif
