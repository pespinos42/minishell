#include "minishell.h"

t_all g_data;

int ft_strlen(char const *str)
{
    int len = 0;

    while (str[len])
        len++;
    return (len);
}

char	*ft_strdup(char *src)
{
	char	*str;
	int	p = 0;

	str = malloc ((ft_strlen(src) + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (src[p])
	{
		str[p] = src[p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	p = 0;
	char	*str;

	if (ft_strlen(s) < start)
		return (ft_strdup(""));
	if (ft_strlen(&s[start]) < len)
		len = ft_strlen(&s[start]);
	str = malloc ((len + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (s[start+p] && p < len)
	{
		str[p] = s[start+p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

int	ft_num_words(char const *s, char c)
{
	int	q = 0;
	int	p = 0;
	int	first = 1;

	while (s[p])
	{
		if (s[p] != c && s[p] != '\0' && first == 1)
		{
			q++;
			first = 0;
		}
		if (s[p] == c)
			first = 1;
		p++;
	}
	return (q);
}

char	**ft_split(char const *s, char c)
{
	char	**result;
	int	q = 0;
	int	p = 0;
	int	start = 0;

	result = malloc ((ft_num_words(s, c) + 1) * sizeof (char *));
	if (!result)
		return (NULL);
	while (s[p] && q < ft_num_words(s, c))
	{
		while (s[p] && s[p] == c)
			p++;
		start = p;
		while (s[p] && s[p] != c)
			p++;
		if (start != p)
			result[q++] = ft_substr(s, start, p - start);
	}
	result[q] = NULL;
	return (result);
}

void ft_print_words(char **str)
{
    int n;

    n = 0;
    while (str[n] != NULL)
    {
        printf("[%i] -> %s\n", n, str[n]);
        n++;
    }
}

void	ft_check_chars()
{
	int	p;

	p = 0;
	g_data.counter_c1 = 0;
	g_data.counter_c2 = 0;
	while (g_data.str_order[p])
	{
		if (g_data.str_order[p] == 39) // '
			g_data.counter_c1++;
		else if (g_data.str_order[p] == 34) // "
			g_data.counter_c2++;
		else if (g_data.str_order[p] == ';')
			g_data.character_error = 1;
		else if (g_data.str_order[p] == '\\')
			g_data.character_error = 1;
		p++;
	}
	if (g_data.counter_c1 % 2 != 0 || g_data.counter_c2 % 2 != 0)
		g_data.character_error = 1;
	printf("TOTAL DE ' -> %d\n", g_data.counter_c1);
	printf("TOTAL DE \" -> %i\n", g_data.counter_c2);
	printf("CHARACTER ERROR -> %i\n", g_data.character_error);
}

void	ft_add_history(char *str)
{
	if (ft_strlen(str) > 0)
		add_history(str);
}

char	*ft_print_entry(char *msg)
{
	char	*str;

	str = readline(msg);
	return (str);
}

void	ft_create_map(void)
{
	printf("DENTRO DE CREATE MAP\n");
	int	n;

	n = 0;
	g_data.map_elements = ft_strlen(g_data.str_order);
	g_data.map = malloc (g_data.map_elements * sizeof (*g_data.map));
	if (!g_data.map)
		return ;
	while (n < g_data.map_elements)
		g_data.map[n++] = -1;
}

void	ft_print_map(void)
{
	printf("DENTRO DE PRINT MAP\n");
	int	n;

	n = 0;
	while (n < g_data.map_elements)
		printf("%i ", g_data.map[n++]);
	printf("\n");
}

void	ft_fill_map(int start_position, int end_position, int value)
{
	int	n;

	n = start_position;
	while (n <= end_position)
	{
		g_data.map[n] = value;
		n++;
	}
}

int	ft_check_open(char letter, int position) //1 - OPEN 0 - CLOSE
{
	int	n;
	int	find;

	n = position + 1;
	find = 0;
	while (g_data.str_order[n] && find == 0)
	{
		if (g_data.str_order[n] == letter)
		{
			g_data.close_position = n;
			find = 1;
		}
		n++;
	}
	if (find == 1)
	{
		if (letter == 34)
			ft_fill_map(position, g_data.close_position, 1);
		else if (letter == 39)
			ft_fill_map(position, g_data.close_position, 0);
		return (0);
	}
	else
		return (1);
}

void	ft_check_str()
{
	int	n;

	n = 0;
	while (g_data.str_order[n])
	{
		if (g_data.str_order[n] == 34)
		{
			printf("\"\n");
			if (ft_check_open(34, n) == 1)
			{
				printf("COMILLAS ABIERTAS\n");
				return ;
			}
			else
				n = g_data.close_position + 1;
		}
		else if (g_data.str_order[n] == 39)
		{
			printf("'\n");
			if (ft_check_open(39, n) == 1)
			{
				printf("COMILLAS ABIERTAS\n");
				return ;
			}
			else
				n = g_data.close_position + 1;
		}
		else
		{
			printf("OTRO CARACTER\n");
			n++;
		}
	}
}

int main()
{
	while ((g_data.str_order = ft_print_entry("minishell >> ")) != NULL)
	{
		printf("LONGITUD DE LA CADENA INTRODUCIDA -> %i\n", ft_strlen(g_data.str_order));
		ft_create_map();
		ft_print_map();
		ft_check_str();
		ft_print_map();
		ft_add_history(g_data.str_order);
		free (g_data.str_order);
		free (g_data.map);
	}
	return (0);
}
