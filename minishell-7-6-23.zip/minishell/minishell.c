#include "minishell.h"

int ft_strlen(char const *str)
{
    int len = 0;

    while (str[len])
        len++;
    return (len);
}

char	*ft_strdup(char *src)
{
	char	*str;
	int	p = 0;

	str = malloc ((ft_strlen(src) + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (src[p])
	{
		str[p] = src[p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	p = 0;
	char	*str;

	if (ft_strlen(s) < start)
		return (ft_strdup(""));
	if (ft_strlen(&s[start]) < len)
		len = ft_strlen(&s[start]);
	str = malloc ((len + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (s[start+p] && p < len)
	{
		str[p] = s[start+p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

int	ft_num_words(char const *s, char c)
{
	int	q = 0;
	int	p = 0;
	int	first = 1;

	while (s[p])
	{
		if (s[p] != c && s[p] != '\0' && first == 1)
		{
			q++;
			first = 0;
		}
		if (s[p] == c)
			first = 1;
		p++;
	}
	return (q);
}

char	**ft_split(char const *s, char c)
{
	char	**result;
	int	q = 0;
	int	p = 0;
	int	start = 0;

	result = malloc ((ft_num_words(s, c) + 1) * sizeof (char *));
	if (!result)
		return (NULL);
	while (s[p] && q < ft_num_words(s, c))
	{
		while (s[p] && s[p] == c)
			p++;
		start = p;
		while (s[p] && s[p] != c)
			p++;
		if (start != p)
			result[q++] = ft_substr(s, start, p - start);
	}
	result[q] = NULL;
	return (result);
}

void ft_print_words(char **str)
{
    int n;

    n = 0;
    while (str[n] != NULL)
    {
        printf("[%i] -> %s\n", n, str[n]);
        n++;
    }
}

int main()
{
    char *input;

    input = readline("minishell >> ");
    while (input == NULL || ft_strlen(input) == 0)
    {
        input = readline("minishell >> ");
    }
    ft_print_words(ft_split(input, ' '));
    free(input);
    return (0);
}