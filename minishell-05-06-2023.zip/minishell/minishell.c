#include "minishell.h"

int ft_strlen(char *str)
{
    int len = 0;

    while (str[len])
        len++;
    return (len);
}

int main()
{
    char *input;

    input = readline("minishell >> ");
    // if (input == NULL || ft_strlen(input) == 0)
    // {
    //     printf("NO HA INTRODUCIDO NINGUN NUMERO\n");
    //     exit(EXIT_FAILURE);
    // }

    while (input == NULL || ft_strlen(input) == 0)
    {
        input = readline("minishell >> ");
    }

    ft_print_ascii(input);
    free(input);
    return (0);
}