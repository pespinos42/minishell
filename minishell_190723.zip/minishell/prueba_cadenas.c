#include <stdio.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	len = 0;

	while (str[len])
		len++;
	return (len);
}

char	*ft_strjoin(char *str1, char *str2)
{
	char 	*str_result;
	int	c1 = 0;
	int	c2 = 0;

	str_result = malloc ((ft_strlen(str1) + ft_strlen(str2) + 1) * sizeof (*str_result));
	if (!str_result)
		return (NULL);
	while (str1[c1])
	{
		str_result[c1] = str1[c1];
		c1++;
	}
	while (str2[c2])
	{
		str_result[c1+c2] = str2[c2];
		c2++;
	}
	str_result[c1+c2] = '\0';
	return (str_result);
}

char	*ft_straddchar(char *str1, char letter)
{
	char	*str_result;
	int	c1 = 0;

	str_result = malloc ((ft_strlen(str1) + 2) * sizeof (*str_result));
	if (!str_result)
		return (NULL);
	while (str1[c1])
	{
		str_result[c1] = str1[c1];
		c1++;
	}
	str_result[c1] = letter;
	str_result[c1 + 1] = '\0';
	return (str_result);
}

int main()
{
	int n = 0;
	char str[] = "HOLA";
	char *str2;

	str2 = malloc (1 * sizeof (*str2));
	printf("ESTADO INICIAL DE HOLA -> %s\n", str2);
	if (!str)
		return (-1);
	while (str[n])
	{
		str2 = ft_straddchar(str2, str[n]);
		printf("str2 = %s\n", str2);
		n++;
	}
	printf("RESULTADO -> %s\n", str2);
	//printf("RESULTADO -> %s\n", ft_strjoin("HOLA", " MUNDO"));
	return (0);
}
