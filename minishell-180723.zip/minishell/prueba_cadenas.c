#include <stdio.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	len = 0;

	while (str[len])
		len++;
	return (len);
}

char	*ft_strjoin(char *str1, char *str2)
{
	char 	*str_result;
	int	c1 = 0;
	int	c2 = 0;

	str_result = malloc ((ft_strlen(str1) + ft_strlen(str2) + 1) * sizeof (*str_result));
	if (!str_result)
		return (NULL);
	while (str1[c1])
	{
		str_result[c1] = str1[c1];
		c1++;
	}
	while (str2[c2])
	{
		str_result[c1+c2] = str2[c2];
		c2++;
	}
	str_result[c1+c2] = '\0';
	return (str_result);
}

int main()
{
	printf("RESULTADO -> %s\n", ft_strjoin("HOLA", " MUNDO"));
	return (0);
}
