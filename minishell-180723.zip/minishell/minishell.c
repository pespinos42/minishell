/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/14 21:50:19 by pespinos          #+#    #+#             */
/*   Updated: 2023/07/14 21:50:19 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

t_all	g_data;

int	ft_strlen(char const *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

char	*ft_strdup(char *src)
{
	char	*str;
	int		p;

	p = 0;
	str = malloc ((ft_strlen(src) + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (src[p])
	{
		str[p] = src[p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	size_t	p;
	char	*str;

	p = 0;
	if (ft_strlen(s) < start)
		return (ft_strdup(""));
	if (ft_strlen(&s[start]) < len)
		len = ft_strlen(&s[start]);
	str = malloc ((len + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (s[start + p] && p < len)
	{
		str[p] = s[start + p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

int	ft_num_words(char const *s, char c)
{
	int	q;
	int	p;
	int	first;

	q = 0;
	p = 0;
	first = 1;
	while (s[p])
	{
		if (s[p] != c && s[p] != '\0' && first == 1)
		{
			q++;
			first = 0;
		}
		if (s[p] == c)
			first = 1;
		p++;
	}
	return (q);
}

char	**ft_split(char const *s, char c)
{
	char	**result;
	int		q;
	int		p;
	int		start;

	q = 0;
	p = 0;
	start = 0;
	result = malloc ((ft_num_words(s, c) + 1) * sizeof (char *));
	if (!result)
		return (NULL);
	while (s[p] && q < ft_num_words(s, c))
	{
		while (s[p] && s[p] == c)
			p++;
		start = p;
		while (s[p] && s[p] != c)
			p++;
		if (start != p)
			result[q++] = ft_substr(s, start, p - start);
	}
	result[q] = NULL;
	return (result);
}

void	ft_print_words(char **str)
{
	int	n;

	n = 0;
	while (str[n] != NULL)
	{
		printf("[%i] -> %s\n", n, str[n]);
		n++;
	}
}

void	ft_add_history(char *str)
{
	if (ft_strlen(str) > 0)
		add_history(str);
}

char	*ft_print_entry(char *msg)
{
	char	*str;

	str = readline(msg);
	return (str);
}

void	ft_create_map(void)
{
	int	n;

	n = 0;
	g_data.map_elements = ft_strlen(g_data.str_order);
	g_data.map = malloc (g_data.map_elements * sizeof (*g_data.map));
	if (!g_data.map)
		return ;
	while (n < g_data.map_elements)
		g_data.map[n++] = -1;
}

void	ft_print_map(void)
{
	int	n;

	n = 0;
	while (n < g_data.map_elements)
		printf("%i ", g_data.map[n++]);
	printf("\n");
}

void	ft_fill_map(int start_position, int end_position, int value)
{
	int	n;

	n = start_position;
	while (n <= end_position)
	{
		g_data.map[n] = value;
		n++;
	}
}

//1 - OPEN 0 - CLOSE
int	ft_check_open(char letter, int position)
{
	int	n;
	int	find;

	n = position + 1;
	find = 0;
	while (g_data.str_order[n] && find == 0)
	{
		if (g_data.str_order[n] == letter)
		{
			g_data.close_position = n;
			find = 1;
		}
		n++;
	}
	if (find == 1)
	{
		if (letter == 34)
			ft_fill_map(position, g_data.close_position, 1);
		else if (letter == 39)
			ft_fill_map(position, g_data.close_position, 0);
		return (0);
	}
	else
		return (1);
}

void	ft_check_str(void)
{
	int	n;

	n = 0;
	while (g_data.str_order[n])
	{
		if (g_data.str_order[n] == 34)
		{
			if (ft_check_open(34, n) == 1)
				return ;
			else
				n = g_data.close_position + 1;
		}
		else if (g_data.str_order[n] == 39)
		{
			if (ft_check_open(39, n) == 1)
				return ;
			else
				n = g_data.close_position + 1;
		}
		else
			n++;
	}
}

//1 - FOUND 0 - NOT FOUND
int	ft_search_char(char letter)
{
	int	n;

	n = 0;
	while (g_data.str_order[n])
	{
		if (g_data.str_order[n] == letter)
			return (1);
		n++;
	}
	return (0);
}

char	*ft_expand_var(char *str)
{
	char	*str_return;

	str_return = getenv(str);
	return (str_return);
}

char	*ft_get_word(char *str, int position)
{
	int	start;
	int	len;

	start = position;
	len = 0;
	while (str[position] != ' ' && str[position] != '$' && str[position])
	{
		len++;
		position++;
	}
	printf("CADENA A CORTAR -> %s\nPOSICION INICIAL -> %i\nLONGITUD A CORTAR -> %i\n", str, start, len);
	return (ft_substr(str, start, len));
}


void	ft_check_env_vars(void)
{
	int	n;

	n = 0;
	while (g_data.str_order[n])
	{
		if (g_data.str_order[n] == '$')
			printf("VARIABLE DE ENTORNO -> %s\n", ft_get_word(g_data.str_order, n + 1));
		n++;
	}

}

int	main(void)
{
	g_data.str_order = ft_print_entry("minishell >> ");
	while (g_data.str_order != NULL)
	{
		if (ft_search_char(';') || ft_search_char('\\'))
		{
			printf("CARACTERES ERRONEOS\n");
			return (-1);
		}
		ft_create_map();
		ft_print_map();
		ft_check_str();
		ft_print_map();
		ft_check_env_vars();
		ft_add_history(g_data.str_order);
		free (g_data.str_order);
		g_data.str_order = ft_print_entry("minishell >> ");
	}
	printf("$USER = %s\n", ft_expand_var("USER"));
	free (g_data.map);
	return (0);
}
